source("../dreg-train/dregpipe-fast.R");

source("dregpipe-param.R");

load( "../dreg-train/dregpipe-fast-infp.rdata");

infp_list[[8]]<-list( plus=file.bw.GM[1], minus=file.bw.GM[2], infp=get_informative_positions( file.bw.GM[1], file.bw.GM[2], depth= 0, step=50, use_ANDOR=TRUE, use_OR=FALSE ));

setwd("../dreg-train/")

load("k562.positive.bed.rdata");
k562.positive.bed <- positive_bed;
load("k562.negative.bed.rdata");
k562.negative.bed <- negative_bed;
rm(negative_bed);
rm(positive_bed);

load("../GM12878/GM12878.positive.bed.rdata");
GM.positive.bed <- positive_bed;
load("../GM12878/GM12878.negative.bed.rdata");
GM.negative.bed <- negative_bed;

g.neg.amp <- 32 #(3%)
r1235M.fast <- dregpipe( gdm, 
   c(file.bw.G6[1], file.bw.G5[1], file.bw.G3[1], file.bw.G7[1], file.bw.G1[1]), 
   c(file.bw.G6[2], file.bw.G5[2], file.bw.G3[2], file.bw.G7[2], file.bw.G1[2]), 
   20000,  
   10000, 
   infp_list,
   list(infp_list[[6]]$infp,  infp_list[[5]]$infp ,infp_list[[3]]$infp, infp_list[[7]]$infp, infp_list[[1]]$infp), 
   "dregf1-G13567-20k-p3-G1-7",  
   "Train G13567:20K-3%pos/Test G1-7",
   positive.bed = list(k562.positive.bed, k562.positive.bed, k562.positive.bed, k562.positive.bed, k562.positive.bed),
   negative.bed = list(k562.negative.bed, k562.negative.bed, k562.negative.bed, k562.negative.bed, k562.negative.bed))

setwd("../gr-review");

system("mail -s 'Check results' 'zw355@cornell.edu' <<EOF\n g.neg.amp <- 1.5 \nEOF")
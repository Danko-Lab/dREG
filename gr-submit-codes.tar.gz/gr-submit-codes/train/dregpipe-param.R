
file.bw.G1 <- c( "../k562/K562_unt.sort.bed.gz_plus.bw", "../k562/K562_unt.sort.bed.gz_minus.bw");
file.bw.G2 <- c( "../k562/groseq_plus.bigWig", "../k562/groseq_minus.bigWig");
file.bw.G3 <- c( "../k562/K562_Nuc_NoRNase_plus.bw", "../k562/K562_Nuc_NoRNase_minus.bw");
file.bw.G4 <- c( "../k562/K562_Nuc_RNase_plus.bw", "../k562/K562_Nuc_RNase_minus.bw");
file.bw.G5 <- c( "../k562/K562_FC_NHS_BRs_normalized_pl.bigWig", "../k562/K562_FC_NHS_BRs_normalized_mn.bigWig");
file.bw.G6 <- c( "../k562/6045_7157_27170_HNHKJBGXX_K562_0min_celastrol10uM_rep1_GB_ATCACG_R1_plus.primary.bw", "../k562/6045_7157_27170_HNHKJBGXX_K562_0min_celastrol10uM_rep1_GB_ATCACG_R1_minus.primary.bw");
file.bw.G7 <- c( "../k562/6045_7157_27176_HNHKJBGXX_K562_0min_celastrol10uM_rep2_GB_CAGATC_R1_plus.primary.bw", "../k562/6045_7157_27176_HNHKJBGXX_K562_0min_celastrol10uM_rep2_GB_CAGATC_R1_minus.primary.bw");
file.bw.G8 <- c( "../k562/SRR182390x_plus.bw", "../k562/SRR182390x_minus.bw");
file.bw.GM <- c( "../GM12878/groseq_plus.bigWig", "../GM12878/groseq_minus.bigWig");

file.genecode.merge <- "../k562/GencodeMerge.IntersectOpStrand.bed"
file.enh.prom.bed <- "../k562/chromHmm.k562.enh.prom.bed.gz";
file.dnase.peakcalling <- "../k562/GSM646567_hg19_wgEncodeUwDgfK562Pk.macs2.narrowPeak"
file.grocap <- "../k562/hg19.k562.new_hmm2b.post2.bed"

gdm <- genomic_data_model(window_sizes= c(10, 25, 50, 500, 5000), half_nWindows= c(10, 10, 30, 20, 20) )

file.bw.plus7  <- c(file.bw.G1[1], file.bw.G2[1],file.bw.G3[1], file.bw.G4[1], file.bw.G5[1], file.bw.G6[1], file.bw.G7[1]);
file.bw.minus7 <- c(file.bw.G1[2], file.bw.G2[2],file.bw.G3[2], file.bw.G4[1], file.bw.G5[2], file.bw.G6[2], file.bw.G7[2]);
use_rgtsvm = TRUE;
remove.q = 0.0;
g.svmtuning <- F;
#g.neg.amp <- 1.5 #(60%)
g.neg.amp <- 2.4 #(70%)
g.neg.amp <- 4 #(80%)

#infp
file.infp.rdata <-  "dregpipe-fast-infp.rdata"
#positive_bed
file.positive.bed <- "k562.positive.bed.rdata"
#negative_bed
file.negative.bed <- "k562.negative.bed.rdata"


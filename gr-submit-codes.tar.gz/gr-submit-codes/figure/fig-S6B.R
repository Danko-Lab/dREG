if(1)
{
tpr.grocap.G8 <- c( 0.819, 0.821, 0.802, 0.751)
tpr.grocap.gm <- c( 0.961, 0.966, 0.966, 0.970)
tpr.h3k27ac.G8 <- c( 0.645, 0.626, 0.605, 0.580)
tpr.h3k27ac.gm <- c( 0.718, 0.719, 0.702, 0.670)
tpr.h3k27ac.gh <- c( 0.841, 0.840, 0.839, 0.807)


cols=c("#cb5b42", "#6985cd", "#cbf21f",  "purple");

pdf("fig-S6B.pdf");
x <- cbind( C11=tpr.grocap.G8,  C12=tpr.grocap.gm,  #C14=tpr.grocap.gh, 
            C21=tpr.h3k27ac.G8, C22=tpr.h3k27ac.gm, C23=tpr.h3k27ac.gh);
x.names <- c("G8/GRO-cap", "GM/GRO-cap", "G8/H3K27ac", "GM/H3K27ac", "GH/H3K27ac");

barplot(x, xlab="", ylab= "TPR", beside=TRUE, col=cols, ylim=c(0,1.05), names.arg=x.names, cex.axis=0.95, cex.names=0.8, cex.lab=0.8)

# Place the legend at the top-left corner with no frame
# using rainbow colors
legend("topright", c("Current Model(Trained G1,2,3,5,6)","Trained by G1,2,3,5,8", "Trained by G1,2,3,5,M", "Trained by GM"), cex=1.0,  bty="n", fill=cols);

dev.off()
}


if(0)
{
#           GC.count  GC.FDR GC.TPR GM.count  GM.FDR GM.TPR
#G8/GRO-cap      920 0.07391 0.7555      793 0.05927 0.6868
#GM/GRO-cap     1627 0.07560 0.9475     1537 0.06116 0.9449
#G8/H3k27ac      920 0.06304 0.5690      793 0.02900 0.5036
#GM/H3k27ac     1627 0.04179 0.6837     1537 0.02212 0.6235

tpr.grocap.G8 <- c( 0.756, 0.687)
tpr.grocap.gm <- c( 0.948, 0.945)
tpr.h3k27ac.G8 <- c( 0.569, 0.504)
tpr.h3k27ac.gm <- c( 0.684, 0.624)


cols=c( "#cb5b42", "purple");

pdf("fig-S6B-chr22.pdf");
x <- cbind( C11=tpr.grocap.G8,  C12=tpr.grocap.gm, 
            C21=tpr.h3k27ac.G8, C22=tpr.h3k27ac.gm);
x.names <- c("G8/GRO-cap", "GM/GRO-cap", "G8/H3K27ac", "GM/H3K27ac");

barplot(x, xlab="", ylab= "TPR", beside=TRUE, col=cols, ylim=c(0,1.05), names.arg=x.names, cex.axis=0.95, cex.names=0.8, cex.lab=0.8)

# Place the legend at the top-left corner with no frame
# using rainbow colors
legend("topright", c("Current Model(Trained G1,2,3,5,6)", "Trained by GM"), cex=1.0,  bty="n", fill=cols);

dev.off()
}
